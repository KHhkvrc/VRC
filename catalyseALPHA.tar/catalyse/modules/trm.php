<?php
function tracm() {
  $data = @unserialize(file_get_contents('http://ip-api.com/php/'));
  $FCL="\033[01;33m";
  $MCL="\033[01;37m>\033[01;32m";
  $NCL="\033[00m";
  system("clear");
  date_default_timezone_set($data['timezone']);
  echo <<<EOL
\033[01;33m


             CATALYSE  
           VERSION ALPHA
Author :- ❀Ҝ卄❀ - ᑕᕼ0ᑎ0ᔕ - ∩⅄∩S⊥


   \033[01;37m}\033[01;31m----------------------------------------\033[01;37m{
}\033[01;31m--------------- \033[01;32mIP Information\033[01;31m ---------------\033[01;37m{
   }\033[01;31m----------------------------------------\033[01;37m{

\033[00m
EOL;

if(!empty($data['status']) && $data['status'] == 'success') {
  echo "\n ".$FCL."IP Address    ".$MCL."   ".$data['query'];
  echo "\n ".$FCL."Code postal  ".$MCL."    ".$data['countryCode'];
  echo "\n ".$FCL."Pays       ".$MCL."      ".$data['country'];
  echo "\n ".$FCL."Indicatif régional       ".$MCL."   ".$data['region'];
  echo "\n ".$FCL."Region        ".$MCL."   ".$data['regionName'];
  echo "\n ".$FCL."Ville         ".$MCL."   ".$data['city'];
  echo "\n ".$FCL."Zip code      ".$MCL."   ".$data['zip'];
  echo "\n ".$FCL."ISP           ".$MCL."   ".$data['isp'];
  echo "\n ".$FCL."Organization  ".$MCL."   ".$data['org'];
  echo "\n ".$FCL."ASN           ".$MCL."   ".$data['as'];
  echo "\n ".$FCL."Latitude      ".$MCL."   ".$data['lat'];
  echo "\n ".$FCL."Longtitude    ".$MCL."   ".$data['lon'];
  echo "\n ".$FCL."Location      ".$MCL."   ".$data['lat'].",".$data['lon'];
  echo "\n\n$NCL";
  } else {
    echo "\033[Dev catalyse : \033[01;33m ❀Ҝ卄❀ \033[01;31m ᑕᕼ0ᑎ0ᔕ \033[01;33m ∩⅄∩S⊥ \033[01;31m !!\033[00m\n\n";
}
  }
  $prompt="\033[01;37m";
  echo $prompt;
  $getact = readline(' IP-Tracer >> ');
  menu();

?>
