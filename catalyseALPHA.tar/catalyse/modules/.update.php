<?php
include("modules/trm.php");
include("modules/help.php");
include("modules/trip.php");

function logo() {
  system("clear");
  echo <<<EOL
\033[01;33m
 
             CATALYSE  
           VERSION ALPHA
Author :- ❀Ҝ卄❀ - ᑕᕼ0ᑎ0ᔕ - ∩⅄∩S⊥


   \033[01;37m}\033[01;31m----------------------------------------\033[01;37m{
}\033[01;31m-------------- \033[01;32mTrack IPLocation\033[01;31m --------------\033[01;37m{
   }\033[01;31m----------------------------------------\033[01;37m{

\033[00m
EOL;
}

function upd() {
  logo();
  echo "\n\033[01;32mUpdate CATALYSE.........\033[01;37m\n\n";
  sleep(1);

  logo();
  echo "\n\033[01;32m              catalyse update !!!\033[01;37m\n";
  sleep(1);
}
upd();
?>
