<?php
function help() {
    logo();
    echo <<<EOL

    033[1;36m\  
             CATALYSE  
           VERSION ALPHA
Author :- ❀Ҝ卄❀ - ᑕᕼ0ᑎ0ᔕ - ∩⅄∩S⊥


    \033[01;37m ----------------------------------------------
    |         \033[01;36mcommand\033[01;37m       |        \033[01;36mCATALYSE\033[01;37m           |
     ----------------------------------------------
    | \033[01;32mtrace -m\033[01;37m              | \033[01;33mTrack ton IP\033[01;37m        |
    | \033[01;32mtrace -t <traget-ip>\033[01;37m  | \033[01;33mTrack IP\033[01;37m             |
    | \033[01;32mtracer --help\033[01;37m         | \033[01;33mPour plus d'informations\033[01;37m |
     ----------------------------------------------
    
    \033[01;31mNote :- ip-api bannira automatiquement toutes les adresses IP faisant plus de 150 requêtes par minute.\033[00m
    
    

EOL;
  $prompt="\033[00m";
  echo $prompt;
  $getact = readline(' IP-Tracer >> ');
  menu();
}
?>
